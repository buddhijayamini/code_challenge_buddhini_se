<?php

namespace App\Repositories\Match;

use App\Models\Matches;

/**
 * Class MatchRepository.
 */
class MatchRepository implements MatchInterface
{
        /**
    * @var Matches
    */
    protected $model;

   /**
    * BaseRepository constructor.
    *
    * @param Matches $model
    */
   public function __construct(Matches $model)
   {
       $this->model = $model;
   }

    public function getAll() : object
    {
        $query = $this->model->query();
        $query = $this->getFilters($query);
        return $query->paginate(10);
    }

    private function getFilters($query) :object
    {
        if(request()->has('name') && request('name') != null){
            $query = $query->where('name','LIKE','%'.request('name').'%');
        }
        if(request()->has('team_name') && request('team_name') != null){
            $query = $query->where('team_name','LIKE','%'.request('team_name').'%');
        }
        return $query;
    }

    public function getById(int $id) : object
    {
        return $this->model->find($id);
    }

    public function store(array $addDetails) : object
    {
        return $this->model->create($addDetails);
    }

    public function update(int $id, array $newDetails) : bool
    {
        return $this->model->whereId($id)->update($newDetails);
    }

    public function destroy(int $id) : bool
    {
        return $this->model->destroy($id);
    }
}
