<?php

namespace App\Providers;

use App\Repositories\Match\MatchInterface;
use App\Repositories\Match\MatchRepository;
use App\Repositories\Player\PlayerInterface;
use App\Repositories\Player\PlayerRepository;
use App\Repositories\Standing\StandingInterface;
use App\Repositories\Standing\StandingRepository;
use App\Repositories\Team\TeamInterface;
use App\Repositories\Team\TeamRepository;
use App\Repositories\User\UserInterface;
use App\Repositories\User\UserRepository;
use Illuminate\Support\ServiceProvider;

class RepositoryServiceProvider extends ServiceProvider
{
    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        $this->app->bind(UserInterface::class, UserRepository::class);
        $this->app->bind(PlayerInterface::class, PlayerRepository::class);
        $this->app->bind(TeamInterface::class, TeamRepository::class);
        $this->app->bind(MatchInterface::class, MatchRepository::class);
        $this->app->bind(StandingInterface::class, StandingRepository::class);
    }

    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
        //
    }
}
