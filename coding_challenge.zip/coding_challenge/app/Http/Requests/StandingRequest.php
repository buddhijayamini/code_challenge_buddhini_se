<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StandingRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return [
            'team_id' => 'required|exists:tbl_teams,id',
            'matches_played' => 'required|numeric',
            'matches_lost' => 'required|numeric',
            'matches_won' => 'required|numeric',
            'points' => 'required|numeric',
            'runs_scored' => 'required|numeric',
            'overs_faced' => 'required|numeric',
            'runs_conceded' => 'required|numeric',
            'overs_bowled' => 'required|numeric',
            'nrr' => 'required|numeric'
        ];
    }
}
