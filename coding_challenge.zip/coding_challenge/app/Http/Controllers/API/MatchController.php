<?php

namespace App\Http\Controllers\API;

use App\Classes\ApiCatchErrors;
use App\Http\Controllers\Controller;
use App\Http\Requests\MatchRequest;
use App\Http\Resources\Common\ErrorResponse;
use App\Http\Resources\Common\PaginationResource;
use App\Http\Resources\Common\SuccessResponse;
use App\Http\Resources\MatchResource;
use App\Repositories\Match\MatchInterface;
use Exception;
use Illuminate\Support\Facades\DB;

class MatchController extends Controller
{
    protected $matchInterface;

    public function __construct(MatchInterface $matchInterface)
    {
        $this->matchInterface = $matchInterface;
    }

    /**
     * Display a listing of the resource.
     *
     */
    public function index()
    {
        $data = $this->matchInterface->getAll();

        return new SuccessResponse([
            'data' =>  MatchResource::collection($data),
            'pagination' => new PaginationResource($data)
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     */
    public function store(MatchRequest $request)
    {
        DB::beginTransaction();
        try {
            $validatedData = $request->validated();
            $data = $this->matchInterface->store($validatedData);
            DB::commit();

            return new SuccessResponse(
                [
                    'data' => new MatchResource($data),
                ],
            );
        } catch (Exception $e) {
            return ApiCatchErrors::rollback($e);
        }
    }

    /**
     * Display the specified resource.
     *
     */
    public function show(int $id)
    {
        try {
            $data = $this->matchInterface->getById($id);

            return new SuccessResponse(
                [
                    'data' => new MatchResource($data),
                ],
            );
        } catch (Exception $e) {
            return ApiCatchErrors::rollback($e);
        }
    }

    /**
     * Update the specified resource in storage.
     *
     */
    public function update(MatchRequest $request, int $id)
    {
        DB::beginTransaction();
        try{
                $details = $request->validated();
                $data = $this->matchInterface->update($id, $details);
                DB::commit();

                if($data){
                    $record = $this->matchInterface->getById($id);
                    return new SuccessResponse(
                        [
                            'data' => new MatchResource($record),
                            'message' => 'Match updated Successfully.'
                        ],
                    );
                }else{
                    return new ErrorResponse(
                        [
                            'message' => 'Match can not be Updated.'
                        ],
                    );
                }
        }catch(Exception $e){
            return ApiCatchErrors::rollback($e);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     */
    public function destroy(int $id)
    {
        DB::beginTransaction();
        try{
                $data = $this->matchInterface->destroy($id);
                DB::commit();

                if($data){
                    return new SuccessResponse(
                        [
                            'message' => 'Match deleted Successfully.'
                        ],
                    );
                }else{
                    return new ErrorResponse(
                        [
                            'message' => 'Match can not be Deleted.'
                        ],
                    );
                }

        }catch(Exception $e){
            return ApiCatchErrors::rollback($e);
        }
    }
}
