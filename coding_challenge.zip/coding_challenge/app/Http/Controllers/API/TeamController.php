<?php

namespace App\Http\Controllers\API;

use App\Classes\ApiCatchErrors;
use App\Http\Controllers\Controller;
use App\Http\Requests\TeamRequest;
use App\Http\Resources\Common\ErrorResponse;
use App\Http\Resources\Common\PaginationResource;
use App\Http\Resources\Common\SuccessResponse;
use App\Http\Resources\TeamResource;
use App\Repositories\Team\TeamInterface;
use Exception;
use Illuminate\Support\Facades\DB;

class TeamController extends Controller
{
    protected $teamInterface;

    public function __construct(TeamInterface $teamInterface)
    {
        $this->teamInterface = $teamInterface;
    }

    /**
     * Display a listing of the resource.
     *
     */
    public function index()
    {
        $data = $this->teamInterface->getAll();

        return new SuccessResponse([
            'data' =>  TeamResource::collection($data),
            'pagination' => new PaginationResource($data)
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     */
    public function store(TeamRequest $request)
    {
        DB::beginTransaction();
        try {
            $validatedData = $request->validated();
            $data = $this->teamInterface->store($validatedData);
            DB::commit();

            return new SuccessResponse(
                [
                    'data' => new TeamResource($data),
                ],
            );
        } catch (Exception $e) {
            return ApiCatchErrors::rollback($e);
        }
    }

    /**
     * Display the specified resource.
     *
     */
    public function show(int $id)
    {
        try {
            $data = $this->teamInterface->getById($id);

            return new SuccessResponse(
                [
                    'data' => new TeamResource($data),
                ],
            );
        } catch (Exception $e) {
            return ApiCatchErrors::rollback($e);
        }
    }

    /**
     * Update the specified resource in storage.
     *
     */
    public function update(TeamRequest $request, int $id)
    {
        DB::beginTransaction();
        try{
                $details = $request->validated();
                $data = $this->teamInterface->update($id, $details);
                DB::commit();

                if($data){
                    $record = $this->teamInterface->getById($id);
                    return new SuccessResponse(
                        [
                            'data' => new TeamResource($record),
                            'message' => 'Team updated Successfully.'
                        ],
                    );
                }else{
                    return new ErrorResponse(
                        [
                            'message' => 'Team can not be Updated.'
                        ],
                    );
                }
        }catch(Exception $e){
            return ApiCatchErrors::rollback($e);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     */
    public function destroy(int $id)
    {
        DB::beginTransaction();
        try{
                $data = $this->teamInterface->destroy($id);
                DB::commit();

                if($data){
                    return new SuccessResponse(
                        [
                            'message' => 'Team deleted Successfully.'
                        ],
                    );
                }else{
                    return new ErrorResponse(
                        [
                            'message' => 'Team can not be Deleted.'
                        ],
                    );
                }

        }catch(Exception $e){
            return ApiCatchErrors::rollback($e);
        }
    }
}
