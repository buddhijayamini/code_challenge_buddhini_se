<?php

namespace App\Http\Controllers\API;

use App\Classes\ApiCatchErrors;
use App\Http\Controllers\Controller;
use App\Http\Requests\PlayerRequest;
use App\Http\Resources\Common\ErrorResponse;
use App\Http\Resources\Common\PaginationResource;
use App\Http\Resources\Common\SuccessResponse;
use App\Http\Resources\PlayerResource;
use App\Repositories\Player\PlayerInterface;
use Exception;
use Illuminate\Support\Facades\DB;

class PlayerController extends Controller
{
    protected $playerInterface;

    public function __construct(PlayerInterface $playerInterface)
    {
        $this->playerInterface = $playerInterface;
    }

    /**
     * Display a listing of the resource.
     *
     */
    public function index()
    {
        $data = $this->playerInterface->getAll();

        return new SuccessResponse([
            'data' =>  PlayerResource::collection($data),
            'pagination' => new PaginationResource($data)
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     */
    public function store(PlayerRequest $request)
    {
        DB::beginTransaction();
        try {
            $validatedData = $request->validated();
            $data = $this->playerInterface->store($validatedData);
            DB::commit();

            return new SuccessResponse(
                [
                    'data' =>  new PlayerResource($data),
                ],
            );
        } catch (Exception $e) {
            return ApiCatchErrors::rollback($e);
        }
    }

    /**
     * Display the specified resource.
     *
     */
    public function show(int $id)
    {
        try {
            $data = $this->playerInterface->getById($id);

            return new SuccessResponse(
                [
                    'data' => new PlayerResource($data),
                ],
            );
        } catch (Exception $e) {
            return ApiCatchErrors::rollback($e);
        }
    }

    /**
     * Update the specified resource in storage.
     *
     */
    public function update(PlayerRequest $request, int $id)
    {
        DB::beginTransaction();
        try{
                $details = $request->validated();
                $data = $this->playerInterface->update($id, $details);
                DB::commit();

                if($data){
                    $record = $this->playerInterface->getById($id);
                    return new SuccessResponse(
                        [
                            'data' =>  new PlayerResource($record),
                            'message' => 'Player updated Successfully.'
                        ],
                    );
                }else{
                    return new ErrorResponse(
                        [
                            'message' => 'Player can not be Updated.'
                        ],
                    );
                }
        }catch(Exception $e){
            return ApiCatchErrors::rollback($e);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     */
    public function destroy(int $id)
    {
        DB::beginTransaction();
        try{
                $data = $this->playerInterface->destroy($id);
                DB::commit();

                if($data){
                    return new SuccessResponse(
                        [
                            'message' => 'Player deleted Successfully.'
                        ],
                    );
                }else{
                    return new ErrorResponse(
                        [
                            'message' => 'Player can not be Deleted.'
                        ],
                    );
                }

        }catch(Exception $e){
            return ApiCatchErrors::rollback($e);
        }
    }
}
