<?php

namespace App\Http\Controllers\API;

use App\Classes\ApiCatchErrors;
use App\Http\Controllers\Controller;
use App\Http\Requests\StandingRequest;
use App\Http\Resources\Common\ErrorResponse;
use App\Http\Resources\Common\PaginationResource;
use App\Http\Resources\Common\SuccessResponse;
use App\Http\Resources\StandingResource;
use App\Repositories\Standing\StandingInterface;
use Exception;
use Illuminate\Support\Facades\DB;

class StandingController extends Controller
{
    protected $standingInterface;

    public function __construct(StandingInterface $standingInterface)
    {
        $this->standingInterface = $standingInterface;
    }

    /**
     * Display a listing of the resource.
     *
     */
    public function index()
    {
        $data = $this->standingInterface->getAll();

        return new SuccessResponse([
            'data' => StandingResource::collection($data),
            'pagination' => new PaginationResource($data)
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     */
    public function store(StandingRequest $request)
    {
        DB::beginTransaction();
        try {
            $validatedData = $request->validated();
            $validatedData['nrr'] = $this->calNrr($validatedData['runs_scored'],$validatedData['overs_faced'],$validatedData['runs_conceded'],$validatedData['overs_bowled']);
            $data = $this->standingInterface->store($validatedData);
            DB::commit();

            return new SuccessResponse(
                [
                    'data' => new StandingResource($data),
                ],
            );
        } catch (Exception $e) {
            return ApiCatchErrors::rollback($e);
        }
    }

    private function calNrr(int $totRuns, int $totOvers, int $totConced, int $totBowls){
        $nrr = ($totRuns / $totOvers) - ($totConced / $totBowls);
    }
    /**
     * Display the specified resource.
     *
     */
    public function show(int $id)
    {
        try {
            $data = $this->standingInterface->getById($id);

            return new SuccessResponse(
                [
                    'data' => new StandingResource($data),
                ],
            );
        } catch (Exception $e) {
            return ApiCatchErrors::rollback($e);
        }
    }

    /**
     * Update the specified resource in storage.
     *
     */
    public function update(StandingRequest $request, int $id)
    {
        DB::beginTransaction();
        try{
                $details = $request->validated();
                $data = $this->standingInterface->update($id, $details);
                DB::commit();

                if($data){
                    $record = $this->standingInterface->getById($id);
                    return new SuccessResponse(
                        [
                            'data' => new StandingResource($record),
                            'message' => 'Standings updated Successfully.'
                        ],
                    );
                }else{
                    return new ErrorResponse(
                        [
                            'message' => 'Standings can not be Updated.'
                        ],
                    );
                }
        }catch(Exception $e){
            return ApiCatchErrors::rollback($e);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     */
    public function destroy(int $id)
    {
        DB::beginTransaction();
        try{
                $data = $this->standingInterface->destroy($id);
                DB::commit();

                if($data){
                    return new SuccessResponse(
                        [
                            'message' => 'Standings deleted Successfully.'
                        ],
                    );
                }else{
                    return new ErrorResponse(
                        [
                            'message' => 'Standings can not be Deleted.'
                        ],
                    );
                }

        }catch(Exception $e){
            return ApiCatchErrors::rollback($e);
        }
    }
}
