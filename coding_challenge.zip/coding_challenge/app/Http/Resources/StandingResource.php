<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class StandingResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return
        [
            'id' => $this->id,
            'team_name' => new TeamResource($this->team),
            'matches_played' => $this->matches_played,
            'matches_lost' => $this->matches_lost,
            'matches_won' => $this->matches_won,
            'points' => $this->points,
            'runs_scored_or_overs_faced' => $this->runs_scored_or_overs_faced,
            'runs_conceded_or_overs_bowled' => $this->runs_conceded_or_overs_bowled,
            'nrr' => $this->nrr
        ];
    }
}
