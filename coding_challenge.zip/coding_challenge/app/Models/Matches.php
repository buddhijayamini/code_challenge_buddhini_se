<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Matches extends Model
{
    use HasFactory;
    use SoftDeletes;
    protected $table = 'tbl_match_details';
    protected $guarded = [];

    public function team1(){
        return $this->belongsTo(Team::class,'team_1_id');
    }

    public function team2(){
        return $this->belongsTo(Team::class,'team_2_id');
    }

}
