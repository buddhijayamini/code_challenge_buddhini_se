<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Team extends Model
{
    use HasFactory;
    use SoftDeletes;
    protected $table = 'tbl_teams';
    protected $guarded = [];

    public function matches1(){
        return $this->hasMany(Matches::class,'team_1_id');
    }

    public function matches2(){
        return $this->hasMany(Matches::class,'team_2_id');
    }

    public function standings(){
        return $this->hasMany(Standing::class,'team_id');
    }
}
