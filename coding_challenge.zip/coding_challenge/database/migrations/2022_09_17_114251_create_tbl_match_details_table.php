<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_match_details', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('team_1_id');
            $table->foreign('team_1_id')->references('id')->on('tbl_teams')->onDelete('cascade');
            $table->unsignedBigInteger('team_2_id');
            $table->foreign('team_2_id')->references('id')->on('tbl_teams')->onDelete('cascade');
            $table->string('location', 255);
            $table->dateTime('date_time');
            $table->dateTime('created_at')->useCurrent();
            $table->dateTime('updated_at')->nullable();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_match_details');
    }
};
