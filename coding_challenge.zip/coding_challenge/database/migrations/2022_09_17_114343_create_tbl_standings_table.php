<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_standings', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('team_id');
            $table->foreign('team_id')->references('id')->on('tbl_teams')->onDelete('cascade');
            $table->integer('matches_played');
            $table->integer('matches_lost');
            $table->integer('matches_won');
            $table->integer('points');
            $table->double('runs_scored');
            $table->double('overs_faced');
            $table->double('runs_conceded');
            $table->double('overs_bowled');
            $table->double('nrr');
            $table->dateTime('created_at')->useCurrent();
            $table->dateTime('updated_at')->nullable();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_standings');
    }
};
