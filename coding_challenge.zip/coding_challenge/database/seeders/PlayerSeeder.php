<?php

namespace Database\Seeders;

use App\Models\Player;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class PlayerSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $player =  [
            [
              'name' => 'Dasun',
              'team_name' => 'Sri Lanka',
              'email' => 'dasun.cricket.sl@gmail.com',
              'telephone' => '071563256'
            ],
            [
              'name' => 'Chamika',
              'team_name' => 'Sri Lanka',
              'email' => 'chamika.cricket.sl@gmail.com',
              'telephone' => '077586239'
            ],
            [
                'name' => 'Dhoni',
                'team_name' => 'India',
                'email' => 'dhoni.cricket.ind@gmail.com',
                'telephone' => '077586239'
              ],
              [
                'name' => 'Singhe',
                'team_name' => 'India',
                'email' => 'singhe.cricket.ind@gmail.com',
                'telephone' => '+9175896321'
              ],
              [
                'name' => 'Azam',
                'team_name' => 'Pakistan',
                'email' => 'azam.cricket.pak@gmail.com',
                'telephone' => '+9277569872'
              ],
              [
                'name' => 'Hafeez',
                'team_name' => 'Pakistan',
                'email' => 'hafeez.cricket.sl@gmail.com',
                'telephone' => '+9277689817'
              ],
              [
                'name' => 'Khan',
                'team_name' => 'Afghanistan',
                'email' => 'kan.cricket.afg@gmail.com',
                'telephone' => '0937597862'
              ],
              [
                'name' => 'Nabi',
                'team_name' => 'Afghanistan',
                'email' => 'nabi.cricket.afg@gmail.com',
                'telephone' => '093156236'
              ],
              [
                'name' => 'Bell',
                'team_name' => 'England',
                'email' => 'bell.cricket.eng@gmail.com',
                'telephone' => '04475893267'
              ],
              [
                'name' => 'Evison',
                'team_name' => 'England',
                'email' => 'evison.cricket.eng@gmail.com',
                'telephone' => '0447659321'
              ],
              [
                'name' => 'Carley',
                'team_name' => 'Australia',
                'email' => 'carley.cricket.aus@gmail.com',
                'telephone' => '+6176587953'
              ],
              [
                'name' => 'Jak',
                'team_name' => 'Australia',
                'email' => 'jak.cricket.aus@gmail.com',
                'telephone' => '+61576239'
              ],
        ];

        Player::insert($player);
    }
}
