<?php

namespace Database\Seeders;

use App\Models\Matches;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class MatchSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $match =  [
            [
              'team_1_id' => 1,
              'team_2_id' => 2,
              'location' => 'Dubai',
              'date_time' => '2022-09-18 08:37:11.000000'
            ],
            [
                'team_1_id' => 3,
                'team_2_id' => 4,
                'location' => 'Dubai',
                'date_time' => '2022-09-19 08:37:11.000000'
            ],
            [
                'team_1_id' => 5,
                'team_2_id' => 6,
                'location' => 'Dubai',
                'date_time' => '2022-09-20 08:37:11.000000'
            ],
            [
                'team_1_id' => 1,
                'team_2_id' => 6,
                'location' => 'Dubai',
                'date_time' => '2022-09-21 08:37:11.000000'
            ]
        ];

        Matches::insert($match);
    }
}
