<?php

namespace Database\Seeders;

use App\Models\Team;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class TeamSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $team =  [
            [
              'name' => 'SL',
              'no_of_players' => 11,
            ],
            [
                'name' => 'IND',
                'no_of_players' => 11,
            ],
            [
                'name' => 'PAK',
                'no_of_players' => 11,
            ],
            [
                'name' => 'AFG',
                'no_of_players' => 11,
            ],
            [
                'name' => 'ENG',
                'no_of_players' => 11,
            ],
            [
                'name' => 'AUS',
                'no_of_players' => 11,
            ],
        ];

        Team::insert($team);
    }
}
