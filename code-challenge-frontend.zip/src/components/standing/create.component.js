import React, { useEffect, useState } from 'react';
import { useNavigate } from "react-router-dom";
const CreateStanding = () => {
const [teamId, setTeamId] = useState([]);
const [played, setPlayed] = useState("");
const [lost, setLost] = useState("");
const [won, setWon] = useState("");
const [points, setPoint] = useState("");
const [score, setScore] = useState("");
const [face, setFace] = useState("");
const [conce, setConce] = useState("");
const [bowl, setBowl] = useState("");
const navigate = useNavigate();

useEffect(() => {
   const fetchTeam = async () => {
      const response = await fetch(
       `http://localhost:8000/api/v1/team`, {
           method: 'GET',
           headers: {
              'Content-type': 'application/json; charset=UTF-8',
               'Authorization': `Bearer ${localStorage.userToken}`
             },}
      );
      const data = await response.json();
      console.log(data);
      setTeamId(data.data);
   };
   fetchTeam();
}, []);

const addStanding = async (teamId,played,lost,won,points,score,face,conce,bowl) => {
   await fetch('http://localhost:8000/api/v1/standing', {
      method: 'POST',
      body: JSON.stringify({
         team_id: teamId,
         matches_played: played,
         matches_lost: lost,
         matches_won: won,
         points: points,
         runs_scored: score,
         overs_faced:face,
         runs_conceded:conce,
         overs_bowled:bowl
      }),
      headers: {
         'Content-type': 'application/json; charset=UTF-8',
         'Authorization': `Bearer ${localStorage.userToken}`
      },
   })
      .then((response) => response.json())
      .then((data) => {    
         setTeamId('');
         setPlayed('');
         setLost('');
         setWon('');
         setPoint('');
         setScore('');
         setFace('');
         setConce('');
         setBowl('');
         navigate("/standing");
      })
      .catch((err) => {
         console.log(err.message);
      });
};

const handleSubmit = (e) => {
   e.preventDefault();
   addStanding(teamId,played,lost,won,points,score,face,conce,bowl);
};    


return (
   <div className="app">
      <div className="add-post-container">
         <form onSubmit={handleSubmit}>
         <select className="form-control" value={teamId} onChange={teamId}>                
                          {teamId.length > 0 && teamId.map((row) => (
                              <option value={row.id}>{row.name}</option>
                            ))}
                        </select>
                 <br/>
            
             <input type="number" className="form-control" value={played} placeholder="Matches Played" required
               onChange={(e) => setPlayed(e.target.value)}
            />
            <br/>
            <input type="number" className="form-control" value={lost} placeholder="Matches Lost" required
               onChange={(e) => setLost(e.target.value)}
            />
            <br/>
            <input type="number" className="form-control" value={won} placeholder="Matches Won" required
             onChange={(e) => setWon(e.target.value)}
            />
            <br/>
            <input type="number" className="form-control" value={points} placeholder="Points" required
               onChange={(e) => setPoint(e.target.value)}
            />
            <br/>
            <input type="number" className="form-control" value={score} placeholder="Runs Scored" required
               onChange={(e) => setScore(e.target.value)}
            />
            <br/>
            <input type="number" className="form-control" value={face} placeholder="Overs Faced" required
               onChange={(e) => setFace(e.target.value)}
            />
            <br/>
            <input type="number" className="form-control" value={conce} placeholder="Runs Conceded" required
               onChange={(e) => setConce(e.target.value)}
            />
            <br/>
            <input type="number" className="form-control" value={bowl} placeholder="Overs Bowled" required
               onChange={(e) => setBowl(e.target.value)}
            />
            <br/>
            <button type="submit" className='btn btn-primary' > Add Standings</button>
            
         </form>
      </div>
   </div>
);
};

export default CreateStanding;