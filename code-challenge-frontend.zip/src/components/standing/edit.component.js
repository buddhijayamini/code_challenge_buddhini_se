import React, { useEffect, useState } from "react";
import Form from 'react-bootstrap/Form'
import Button from 'react-bootstrap/Button';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import { useNavigate, useParams } from 'react-router-dom'
import Swal from 'sweetalert2';

export default function EditStanding() {
  const navigate = useNavigate();

  const { id } = useParams();
  
  const [teamId, setTeamId] = useState([]);
  const [played, setPlayed] = useState("");
  const [lost, setLost] = useState("");
  const [won, setWon] = useState("");
  const [points, setPoint] = useState("");
  const [score, setScore] = useState("");
  const [face, setFace] = useState("");
  const [conce, setConce] = useState("");
  const [bowl, setBowl] = useState("");
  const [validationError,setValidationError] = useState({})

  useEffect(() => {
    const fetchTeam = async () => {
       const response = await fetch(
        `http://localhost:8000/api/v1/team/${id}`, {
            method: 'GET',
            headers: {
               'Content-type': 'application/json; charset=UTF-8',
                'Authorization': `Bearer ${localStorage.userToken}`
              },}
       );
       const data = await response.json();
       console.log(data);
       setTeamId(data.data);
    };
    fetchTeam();
 }, []);
   
  

  const updateStanding = async (e) => {
    e.preventDefault();

    await fetch(`http://localhost:8000/api/v1/standing/${id}`, {
        method: 'PUT',
        body: JSON.stringify({
          team_id: teamId,
          matches_played: played,
          matches_lost: lost,
          matches_won: won,
          points: points,
          runs_scored: score,
          overs_faced:face,
          runs_conceded:conce,
          overs_bowled:bowl
         }),
        headers: {
           'Content-type': 'application/json; charset=UTF-8',
           'Authorization': `Bearer ${localStorage.userToken}`
            },
     })
        .then((response) => response.json())
        .then((data) => {    
          setTeamId('');
          setPlayed('');
          setLost('');
          setWon('');
          setPoint('');
          setScore('');
          setFace('');
          setConce('');
          setBowl('');
           Swal.fire({
                icon:"success",
                text:data.message
              });
           navigate("/standing");
        })
        .catch((err) => {
           console.log(err.message);
           if(err.status===422){
                setValidationError(err.data.errors)
              }else{
                Swal.fire({
                  text:err.message,
                  icon:"error"
                })
              }
        });
  }

  return (
    <div className="container">
      <div className="row justify-content-center">
        <div className="col-12 col-sm-12 col-md-6">
          <div className="card">
            <div className="card-body">
              <h4 className="card-title">Update Standing</h4>
              <hr />
              <div className="form-wrapper">
                {
                  Object.keys(validationError).length > 0 && (
                    <div className="row">
                      <div className="col-12">
                        <div className="alert alert-danger">
                          <ul className="mb-0">
                            {
                              Object.entries(validationError).map(([key, value])=>(
                                <li key={key}>{value}</li>   
                              ))
                            }
                          </ul>
                        </div>
                      </div>
                    </div>
                  )
                }
                <Form onSubmit={updateStanding}>
                  <Row> 
                      <Col>
                        <Form.Group controlId="Name">
                            <Form.Label>Team Name</Form.Label>
                            <Form.Control type="number" required value={teamId} onChange={(event)=>{
                              setTeamId(event.target.value)
                            }}/>
                        </Form.Group>
                      </Col>  
                  </Row>
                  <Row>
                      <Col>
                        <Form.Group controlId="played">
                            <Form.Label>Matches Played</Form.Label>
                            <Form.Control type="number" required value={played} onChange={(event)=>{
                              setPlayed(event.target.value)
                            }}/>
                        </Form.Group>
                      </Col>
                  </Row>
                  <Row>
                      <Col>
                        <Form.Group controlId="lost">
                            <Form.Label>Matches Lost</Form.Label>
                            <Form.Control type="number" required value={lost} onChange={(event)=>{
                              setLost(event.target.value)
                            }}/>
                        </Form.Group>
                      </Col>
                  </Row>
                  <Row>
                    <Col>
                      <Form.Group controlId="won" className="mb-3">
                        <Form.Label>Matches Won</Form.Label>
                        <Form.Control type="number" required value={won} onChange={(event)=>{
                              setWon(event.target.value)
                            }}/>
                      </Form.Group>
                    </Col>
                  </Row>
                  <Row>
                    <Col>
                      <Form.Group controlId="points" className="mb-3">
                        <Form.Label>Points</Form.Label>
                        <Form.Control type="number" required value={points} onChange={(event)=>{
                              setPoint(event.target.value)
                            }}/>
                      </Form.Group>
                    </Col>
                  </Row>
                  <Row>
                      <Col>
                      <Form.Group controlId="score" className="mb-3">
                        <Form.Label>Runs Scored</Form.Label>
                        <Form.Control type="number" required value={score} onChange={(event)=>{
                              setScore(event.target.value)
                            }}/>
                      </Form.Group>
                      </Col>
                  </Row>
                  <Row>
                      <Col>
                      <Form.Group controlId="face" className="mb-3">
                        <Form.Label>Overs Faced</Form.Label>
                        <Form.Control type="number" required value={face} onChange={(event)=>{
                              setFace(event.target.value)
                            }}/>
                      </Form.Group>
                      </Col>
                  </Row>
                  <Row>
                      <Col>
                      <Form.Group controlId="conce" className="mb-3">
                        <Form.Label>Runs Conceded</Form.Label>
                        <Form.Control type="number" required value={conce} onChange={(event)=>{
                              setConce(event.target.value)
                            }}/>
                      </Form.Group>
                      </Col>
                  </Row>
                  <Row>
                      <Col>
                      <Form.Group controlId="bowl" className="mb-3">
                        <Form.Label>Overs Bowled</Form.Label>
                        <Form.Control type="number" required value={bowl} onChange={(event)=>{
                              setBowl(event.target.value)
                            }}/>
                      </Form.Group>
                      </Col>
                  </Row>
                  <Button variant="primary" className="mt-2" size="lg" block="block" type="submit">
                    Update
                  </Button>
                </Form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}