import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import Button from 'react-bootstrap/Button';
import Swal from 'sweetalert2';
import { useNavigate } from "react-router-dom";

export default function List() {

    const [standing, setStanding] = useState([]);
    const navigate = useNavigate();

    useEffect(() => {
        const fetchStanding = async () => {
           const response = await fetch(
              'http://localhost:8000/api/v1/standing', {
                method: 'GET',
                headers: {
                   'Content-type': 'application/json; charset=UTF-8',
                    'Authorization': `Bearer ${localStorage.userToken}`,
               
                },}
           );
           const data = await response.json();
           //console.log(data);
           setStanding(data.data);
        };
        fetchStanding();
     }, []);
    
    const deleteStanding = async (id) => {
        const isConfirm = await Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
          }).then((result) => {
             return  result.isConfirmed;
          });

          if(!isConfirm){
            return;
          }

           await fetch(
            `http://localhost:8000/api/v1/standing/${id}`, {
              method: 'DELETE',
              headers: {
                 'Content-type': 'application/json; charset=UTF-8',
                 'Authorization': `Bearer ${localStorage.userToken}`
                  },}
          ).then(({data})=>{
            Swal.fire({
                icon:"success",
                text:data.message
            });
            //navigate("/standing");
           // window.location.reload();
          }).catch(({response:{data}})=>{
            Swal.fire({
                text:data.message,
                icon:"error"
            })
          })
    }

    return (
      <div className="container">
          <div className="row">
            <div className='col-12'>
                <Link className='btn btn-primary mb-2 float-end' to={"/standing/create"}>
                    Create Standing
                </Link>
            </div>
            <div className="col-12">
                <div className="card card-body">
                    <div className="table-responsive">
                        <table className="table table-bordered mb-0 text-center">
                            <thead>
                                <tr>
                                    <th>Team</th>
                                    <th>Matches Played</th>
                                    <th>Matches Lost</th>
                                    <th>Matches Won</th>
                                    <th>Points</th>
                                    <th>RunsScored/OversFaced</th>
                                    <th>RunsConceded/OversBowled</th>
                                    <th>NRR</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {
                                    standing.length > 0 && (
                                        standing.map((row, key)=>(
                                            <tr key={key}>
                                                <td>{row.team_id }</td>
                                                <td>{row.matches_played}</td>
                                                <td>{row.matches_lost}</td>
                                                <td>{row.matches_won}</td>
                                                <td>{row.points}</td>
                                                <td>{row.runs_scored_or_overs_faced}</td>
                                                <td>{row.runs_conceded_or_overs_bowled}</td>
                                                <td>{row.nrr}</td>
                                                <td>
                                                    <Link to={`/standing/edit/${row.id}`} className='btn btn-success me-2'>
                                                        Edit
                                                    </Link>
                                                    <Button variant="danger" onClick={()=>deleteStanding(row.id)}>
                                                        Delete
                                                    </Button>
                                                </td>
                                            </tr>
                                        ))
                                    )
                                }
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
          </div>
      </div>
    )
}