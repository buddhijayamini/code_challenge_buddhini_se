import * as React from "react";
import Navbar from "react-bootstrap/Navbar";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import "bootstrap/dist/css/bootstrap.css";

import { BrowserRouter as Router , Routes, Route, Link } from "react-router-dom";

import EditStanding from "./components/standing/edit.component";
import StandingList from "./components/standing/list.component";
import CreateStanding from "./components/standing/create.component";
import Login from "./components/login";

function App() {
  return (<Router>
    <Navbar bg="primary">
      <Container>
        <Link to={"/"} className="navbar-brand text-white">
          Code Challenge 
        </Link>
      </Container>
    </Navbar>

    <Container className="mt-5">
      <Row>
        <Col md={12}>
          <Routes>
            <Route exact path='/' element={<Login />} />
            <Route path="/standing/create" element={<CreateStanding />} />
            <Route path="/standing/edit/:id" element={<EditStanding />} />
            <Route exact path='/standing' element={<StandingList />} />   
          </Routes>
        </Col>
      </Row>
    </Container>
  </Router>);
}

export default App;